var https = require('https');
var qs = require('querystring');
var fs =    require('fs');
var zlib = require('zlib');
var mysql = require("mysql");
var url  = require('url');
var http = require('http');
var net = require('net');

//res_co9_8119370471.html 
/*
var contents = fs.readFileSync('res_co9_8119370471.html', 'utf8');
var linkConfirmedOracle = contents.substr(contents.indexOf("window.location.href ='")+23);
linkConfirmedOracle = linkConfirmedOracle.substr(0, linkConfirmedOracle.indexOf("'"));
console.log(linkConfirmedOracle);
*/
// res_co10_1029138228.html

var contents = fs.readFileSync('res_co10_1029138228.html', 'utf8');
var linkWDSupport = matchAll(contents, /(<a href="https:\/\/wdsupport\.wdc\.com\/warranty\/rmastatussfdc\.asp.*".*?>)/g);
linkWDSupport = linkWDSupport.toString();
linkWDSupport = linkWDSupport.substr(linkWDSupport.indexOf('href="')+6);
linkWDSupport = linkWDSupport.substr(0, linkWDSupport.indexOf('"'));
linkWDSupport = linkWDSupport.replace(/&amp;/g, '&');
linkWDSupport =linkWDSupport.replace('https://wdsupport.wdc.com','');

var headers11 = {
    'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Encoding':'gzip, deflate',
    'Accept-Language':'en-US,en;q=0.5',
    //'Host':'na12.salesforce.com',
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; rv:43.0) Gecko/20100101 Firefox/43.0',
    //'Referer':'https://c.na12.content.force.com/',
    'Connection':'keep-alive'
};
var options11 = {
    hostname: 'wdsupport.wdc.com',
    port: 443,
    path: linkWDSupport,
    method: 'GET',
    cert: fs.readFileSync('VeriSignClass3PublicPrimaryCertificationAuthority-G5.crt'),
    requestCert: true,
    headers: headers11
};
console.log(options11);
console.log('\n\n');

var req11 = https.request(options11, function(res11) {
    console.log("statusCode: ", res11.statusCode);
    console.log("headers: ", res11.headers);
    console.log('\n\n');

    var randomNum = randomInt (1, 9999999999);
    var fileNameTmp = 'res_co11_'+randomNum+'.html';
    var output11 = fs.createWriteStream(fileNameTmp);
    res11.pipe(zlib.createGunzip()).pipe(output11);
    output11.on('finish', function(){
        putOracleToArray(fileNameTmp, null);
    });
});
req11.end();
req11.on('error', function(e) {
    console.error(e);
});

function putOracleToArray(file, response){
    //var fileNameTmp = 'res_co11_6139929690.html';
    var result11Obj = {};
    var contents11 = fs.readFileSync(file, 'utf8');
    var rmaInfoTable = matchAll(contents11, /<table id="rmainfo"[^>]*>([\s\S]*?)<\/table>/g);
    rmaInfoTable = rmaInfoTable[0];
    var rmaInfoTitle = rmaInfoTable.substr(0, rmaInfoTable.indexOf('<table'));
    var rmaInfoContent = rmaInfoTable.substr(rmaInfoTable.indexOf('<table'));
    rmaInfoTitle = matchAll(rmaInfoTitle, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
    rmaInfoTitle = rmaInfoTitle[0];
    rmaInfoTitle = rmaInfoTitle.trim()+'(rmainfo)';
    var rmaInfoContent = matchAll(rmaInfoContent, /<tr[^>]*>([\s\S]*?)<\/tr>/g);
    //console.log(rmaInfoContent);
    var rmaTableObj = new Array();
    for(var irma11=0; irma11<rmaInfoContent.length; irma11++){
        var rmaTd11 = rmaInfoContent[irma11];
        rmaTd11 = matchAll(rmaTd11, /<td[^>]*>([\s\S]*?)<\/td>/g);
        var rmaTrObj = new Array();
        for(var irmaTd11=0; irmaTd11<rmaTd11.length; irmaTd11++){
            var rmaTd11Content = rmaTd11[irmaTd11];
            rmaTd11Content = rmaTd11Content.toString();
            if(rmaTd11Content.indexOf('strong')>= 0){
                rmaTd11Content = matchAll(rmaTd11Content, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
                rmaTd11Content =rmaTd11Content[0];
                rmaTd11Content = rmaTd11Content.trim();
            }
            rmaTrObj.push(rmaTd11Content);
        }
        rmaTableObj.push(rmaTrObj);
    }
    result11Obj[rmaInfoTitle] = rmaTableObj;
    console.log(result11Obj);
    console.log('\n\n\n');


    var receivingDetailTitle = contents11.substr(contents11.indexOf('receivingdetail')-200, contents11.indexOf('receivingdetail'));
    receivingDetailTitle = matchAll(receivingDetailTitle, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
    receivingDetailTitle = receivingDetailTitle[0];
    receivingDetailTitle = receivingDetailTitle.trim()+'(receivingdetail)';
    var receivingDetailTable = matchAll(contents11, /<table id="receivingdetail"[^>]*>([\s\S]*?)<\/table>/g);
    receivingDetailTable = receivingDetailTable[0];
    var receivingDetailContent = receivingDetailTable.substr(receivingDetailTable.indexOf('<table'));
    receivingDetailContent = matchAll(receivingDetailContent, /<tr[^>]*>([\s\S]*?)<\/tr>/g);
    //console.log(rmaInfoContent);
    var rcvTableObj = new Array();
    for(var ircv11=0; ircv11<receivingDetailContent.length; ircv11++){
        var rcvTd11 = receivingDetailContent[ircv11];
        rcvTd11 = matchAll(rcvTd11, /<td[^>]*>([\s\S]*?)<\/td>/g);
        var rcvTrObj = new Array();
        for(var ircvTd11=0; ircvTd11<rcvTd11.length; ircvTd11++){
            var rcvTd11Content = rcvTd11[ircvTd11];
            rcvTd11Content = rcvTd11Content.toString();
            if(rcvTd11Content.indexOf('strong')>= 0){
                rcvTd11Content = matchAll(rcvTd11Content, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
                rcvTd11Content =rcvTd11Content[0];
                rcvTd11Content = rcvTd11Content.trim();
            }
            rcvTrObj.push(rcvTd11Content);
        }
        rcvTableObj.push(rcvTrObj);
    }
    result11Obj[receivingDetailTitle] = rcvTableObj;
    console.log(result11Obj);
    console.log('\n\n\n');

    var shippingDetailTitle = contents11.substr(contents11.indexOf('shippingdetail')-200, contents11.indexOf('shippingdetail'));
    shippingDetailTitle = matchAll(shippingDetailTitle, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
    shippingDetailTitle = shippingDetailTitle[0];
    shippingDetailTitle = shippingDetailTitle.trim()+'(shippingdetail)';
    var shippingDetailTable = matchAll(contents11, /<table id="shippingdetail"[^>]*>([\s\S]*?)<\/table>/g);
    shippingDetailTable = shippingDetailTable[0];
    var shippingDetailContent = shippingDetailTable.substr(shippingDetailTable.indexOf('<table'));
    shippingDetailContent = matchAll(shippingDetailContent, /<tr[^>]*>([\s\S]*?)<\/tr>/g);
    //console.log(rmaInfoContent);
    var shippingTableObj = new Array();
    for(var iship11=0; iship11<shippingDetailContent.length; iship11++){
        var shipTd11 = shippingDetailContent[iship11];
        shipTd11 = matchAll(shipTd11, /<td[^>]*>([\s\S]*?)<\/td>/g);
        var shipTrObj = new Array();
        for(var ishipTd11=0; ishipTd11<shipTd11.length; ishipTd11++){
            var shipTd11Content = shipTd11[ishipTd11];
            shipTd11Content = shipTd11Content.toString();
            if(shipTd11Content.indexOf('strong')>= 0){
                shipTd11Content = matchAll(shipTd11Content, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
                shipTd11Content =shipTd11Content[0];
                shipTd11Content = shipTd11Content.trim();
            }
            shipTrObj.push(shipTd11Content);
        }
        shippingTableObj.push(shipTrObj);
    }
    result11Obj[shippingDetailTitle] = shippingTableObj;
    console.log(result11Obj);
    console.log('\n\n\n');

    var resumeCombineContainer = contents11.substr(contents11.indexOf('rmainfo'));
    resumeCombineContainer = resumeCombineContainer.substr(0, resumeCombineContainer.indexOf('receivingdetail')-11);
    resumeCombineContainer = resumeCombineContainer.substr(resumeCombineContainer.indexOf('</table>')+30);
    var resumeCombine = resumeCombineContainer.substr(0, resumeCombineContainer.indexOf('</table>')+34);
    var resumeDetailCombine = resumeCombineContainer.substr(resumeCombineContainer.indexOf('</table>')+34);

    var resumeCombineTitle = resumeCombine.substr(0, resumeCombine.indexOf('class="bgnormal"'));
    resumeCombineTitle = matchAll(resumeCombineTitle, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
    resumeCombineTitle = resumeCombineTitle[0];
    resumeCombineTitle = resumeCombineTitle.trim()+'(resumerma)';
    var resumeCombineTable = matchAll(resumeCombine, /<table[^>]*>([\s\S]*?)<\/table>/g);
    resumeCombineTable = resumeCombineTable[0];
    var resumeCombineContent = resumeCombineTable.substr(resumeCombineTable.indexOf('<table'));
    resumeCombineContent = matchAll(resumeCombineContent, /<tr[^>]*>([\s\S]*?)<\/tr>/g);
    var resumeCombineTableObj = new Array();
    for(var irs11=0; irs11<resumeCombineContent.length; irs11++){
        var rsTd11 = resumeCombineContent[irs11];
        rsTd11 = matchAll(rsTd11, /<td[^>]*>([\s\S]*?)<\/td>/g);
        var rsTrObj = new Array();
        for(var irsTd11=0; irsTd11<rsTd11.length; irsTd11++){
            var rsTd11Content = rsTd11[irsTd11];
            rsTd11Content = rsTd11Content.toString();
            if(rsTd11Content.indexOf('strong')>= 0){
                rsTd11Content = matchAll(rsTd11Content, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
                rsTd11Content =rsTd11Content[0];
                rsTd11Content = rsTd11Content.trim();
            }
            rsTrObj.push(rsTd11Content);
        }
        resumeCombineTableObj.push(rsTrObj);
    }
    result11Obj[resumeCombineTitle] = resumeCombineTableObj;
    console.log(result11Obj);
    console.log('\n\n\n');

    var resumeDetailCombineTitle = resumeDetailCombine.substr(0, resumeDetailCombine.indexOf('class="bgnormal"'));
    resumeDetailCombineTitle = matchAll(resumeDetailCombineTitle, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
    resumeDetailCombineTitle = resumeDetailCombineTitle[0];
    resumeDetailCombineTitle = resumeDetailCombineTitle.trim()+'(resumedetail)';
    var resumeCombineDetailTable = matchAll(resumeCombine, /<table[^>]*>([\s\S]*?)<\/table>/g);
    resumeCombineDetailTable = resumeCombineDetailTable[0];
    var resumeCombineDetailContent = resumeCombineDetailTable.substr(resumeCombineDetailTable.indexOf('<table'));
    resumeCombineDetailContent = matchAll(resumeCombineDetailContent, /<tr[^>]*>([\s\S]*?)<\/tr>/g);
    var resumeCombineDetailTableObj = new Array();
    for(var irsd11=0; irsd11<resumeCombineDetailContent.length; irsd11++){
        var rsdTd11 = resumeCombineDetailContent[irsd11];
        rsdTd11 = matchAll(rsdTd11, /<td[^>]*>([\s\S]*?)<\/td>/g);
        var rsdTrObj = new Array();
        for(var irsdTd11=0; irsdTd11<rsdTd11.length; irsdTd11++){
            var rsdTd11Content = rsdTd11[irsdTd11];
            rsdTd11Content = rsdTd11Content.toString();
            if(rsdTd11Content.indexOf('strong')>= 0){
                rsdTd11Content = matchAll(rsdTd11Content, /<strong[^>]*>([\s\S]*?)<\/strong>/g);
                rsdTd11Content =rsdTd11Content[0];
                rsdTd11Content = rsdTd11Content.trim();
            }
            rsdTrObj.push(rsdTd11Content);
        }
        resumeCombineDetailTableObj.push(rsdTrObj);
    }
    result11Obj[resumeDetailCombineTitle] = resumeCombineDetailTableObj;
    console.log(result11Obj);
    console.log('\n\n\n');
    
    response.end(JSON.stringify(result11Obj));
}


function randomInt(low, high){
    return Math.floor(Math.random() * (high - low) + low);
}
/*

var contents = fs.readFileSync('res5.html', 'utf8');
var linkCustomerReport = matchAll(contents, /(<a href="\/servlet\/servlet\.Integration\?lid=01rU0000000DTmR.*".*?>)/g);
linkCustomerReport = linkCustomerReport.toString();
linkCustomerReport = linkCustomerReport.substr(linkCustomerReport.indexOf('href="')+6);
linkCustomerReport = linkCustomerReport.substr(0, linkCustomerReport.indexOf('"'));
console.log(linkCustomerReport);
*/

/*
var rmaNumSearch = '85929084';
var contents = fs.readFileSync('res6.html', 'utf8');
var searchResultJson = matchAll(contents, /({searchResultClick.*?})/g);
searchResultJson = searchResultJson.toString().replace('{searchResultClick.setRelatedListQueryData(', '').toString().trim();
searchResultJson = searchResultJson.split(',');
var searchResultJsonObj = {};
if(searchResultJson.length > 0){
    for(var isearch1=0; isearch1<searchResultJson.length; isearch1++){
        var itemIsearch1 = searchResultJson[isearch1].replace('{', '').replace('}', '').replace(/'/g, '');
        var itemSearch1Child = itemIsearch1.split(':');
        if(itemSearch1Child.length === 2){
            searchResultJsonObj[itemSearch1Child[0].toString().trim()] = itemSearch1Child[1].toString().trim();
        }
    }
}
//console.log(searchResultJsonObj);
//console.log('\n\n\n');
var trHtmlList = matchAll(contents, /(<tr class=" dataRow even last first".*?\/tr>)/g);
trHtmlList = trHtmlList.toString();
var thHtmlList = matchAll(trHtmlList, /(<th scope="row".*?\/th>)/g);
thHtmlList = thHtmlList.toString();
//console.log(thHtmlList);
var retUrl = thHtmlList.substr(thHtmlList.indexOf('href="')+6);
retUrl = retUrl.substr(0, retUrl.indexOf('"'));
retUrl = retUrl.replace('&amp;', '&');
//console.log(retUrl);
var clkRecordId = thHtmlList.substr(thHtmlList.indexOf('data-seclki="')+13);
clkRecordId = clkRecordId.substr(0, clkRecordId.indexOf('"'));
//console.log(clkRecordId);
var clkIdHash = thHtmlList.substr(thHtmlList.indexOf('data-seclkh="')+13);
clkIdHash = clkIdHash.substr(0, clkIdHash.indexOf('"'));
//console.log(clkIdHash);
var fullUrlSearchTmp = '/_ui/search/logging/SearchClickLoggingServlet?asPhrase=1&searchType=2&sen=a0L&str='+rmaNumSearch+'&clkLogFlag=1&clkRecordId='+clkRecordId+'&clkQueryGuid='+(searchResultJsonObj.queryGuid)+'&clkCount='+(searchResultJsonObj.count)+'&clkRank=1&clkBucketRank=1&clkIdHash='+clkIdHash+'&clkNumResultsForEntityBeforeDb='+(searchResultJsonObj.numResultsForEntityBeforeDb)+'&clkPageNum='+(searchResultJsonObj.pageNum)+'&clkNumResultsPerPage='+(searchResultJsonObj.numResultsPerPage)+'&clkFilter='+(searchResultJsonObj.isTagging)+'&filter='+(searchResultJsonObj.sort)+'&clkIsTagging='+(searchResultJsonObj.isTagging)+'&clkEntityName='+(searchResultJsonObj.name)+'&retURL='+retUrl+'& HTTP/1.1';
console.log(fullUrlSearchTmp);
*/

function matchAll(str, regex) {
    var res = [];
    var m;
    if (regex.global) {
        while (m = regex.exec(str)) {
            res.push(m[1]);
        }
    } else {
        if (m = regex.exec(str)) {
            res.push(m[1]);
        }
    }
    return res;
}